# TUMOUR-DETECTION
This project combines the use of the Machine learning and Web Development .It comprises of user friendly and login website which tell the probability of the brain tumor. 
